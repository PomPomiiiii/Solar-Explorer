import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { Sphere } from "@react-three/drei";

export default function Sun({ onPositionUpdate }) {
  const meshRef = useRef();
  const coronaRef = useRef();
  const corona2Ref = useRef();

  useFrame((state, delta) => {
    if (meshRef.current) meshRef.current.rotation.y += delta * 0.005;
    if (coronaRef.current) {
      coronaRef.current.rotation.z += delta * 0.003;
      const pulse = 1 + Math.sin(state.clock.elapsedTime * 0.8) * 0.02;
      coronaRef.current.scale.setScalar(pulse);
    }
    if (corona2Ref.current) {
      corona2Ref.current.rotation.z -= delta * 0.002;
      const pulse2 = 1 + Math.sin(state.clock.elapsedTime * 0.5 + 1) * 0.015;
      corona2Ref.current.scale.setScalar(pulse2);
    }
    if (onPositionUpdate) {
      onPositionUpdate(0, { x: 0, y: 0, z: 0 });
    }
  });

  return (
    <group position={[0, 0, 0]}>
      {/* Core */}
      <Sphere ref={meshRef} args={[3.5, 64, 64]}>
        <meshStandardMaterial
          color="#FDB813"
          emissive="#FF6600"
          emissiveIntensity={1.5}
          roughness={1}
          metalness={0}
        />
      </Sphere>

      {/* Inner glow */}
      <Sphere args={[3.8, 32, 32]}>
        <meshBasicMaterial color="#FF8800" transparent opacity={0.15} side={2} />
      </Sphere>

      {/* Outer corona */}
      <Sphere ref={coronaRef} args={[4.3, 32, 32]}>
        <meshBasicMaterial color="#FF6600" transparent opacity={0.08} side={2} />
      </Sphere>

      <Sphere ref={corona2Ref} args={[5.2, 32, 32]}>
        <meshBasicMaterial color="#FF4400" transparent opacity={0.04} side={2} />
      </Sphere>

      {/* Sun light */}
      <pointLight
        position={[0, 0, 0]}
        intensity={4}
        distance={300}
        decay={1.2}
        color="#FFF5E0"
        castShadow
      />
    </group>
  );
}
