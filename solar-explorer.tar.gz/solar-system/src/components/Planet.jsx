import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import { Sphere, Torus } from "@react-three/drei";
import * as THREE from "three";

function SaturnRings({ color, size }) {
  return (
    <>
      <Torus args={[size * 1.6, size * 0.18, 2, 80]} rotation={[Math.PI / 2.5, 0, 0]}>
        <meshBasicMaterial color={color} transparent opacity={0.7} side={THREE.DoubleSide} />
      </Torus>
      <Torus args={[size * 2.0, size * 0.12, 2, 80]} rotation={[Math.PI / 2.5, 0, 0]}>
        <meshBasicMaterial color={color} transparent opacity={0.45} side={THREE.DoubleSide} />
      </Torus>
      <Torus args={[size * 2.35, size * 0.08, 2, 80]} rotation={[Math.PI / 2.5, 0, 0]}>
        <meshBasicMaterial color={color} transparent opacity={0.25} side={THREE.DoubleSide} />
      </Torus>
    </>
  );
}

function UranusRings({ color, size }) {
  return (
    <Torus args={[size * 1.8, size * 0.06, 2, 60]} rotation={[0, 0, 0]}>
      <meshBasicMaterial color={color} transparent opacity={0.35} side={THREE.DoubleSide} />
    </Torus>
  );
}

function PlanetGlow({ color, size }) {
  return (
    <Sphere args={[size * 1.18, 32, 32]}>
      <meshBasicMaterial color={color} transparent opacity={0.08} side={THREE.BackSide} />
    </Sphere>
  );
}

function CloudLayer({ size }) {
  const cloudRef = useRef();
  useFrame((_, delta) => {
    if (cloudRef.current) cloudRef.current.rotation.y += delta * 0.005;
  });
  return (
    <Sphere ref={cloudRef} args={[size * 1.015, 32, 32]}>
      <meshBasicMaterial color="#ffffff" transparent opacity={0.12} />
    </Sphere>
  );
}

export default function Planet({
  planet,
  index,
  isActive,
  onPositionUpdate,
}) {
  const meshRef = useRef();
  const groupRef = useRef();
  const angleRef = useRef(index * ((Math.PI * 2) / 8));

  const material = useMemo(() => {
    const isGasGiant = ["jupiter", "saturn", "uranus", "neptune"].includes(planet.id);

    if (planet.id === "earth") {
      return (
        <meshStandardMaterial
          color={planet.color}
          emissive={planet.emissive}
          emissiveIntensity={0.1}
          roughness={0.6}
          metalness={0.1}
        />
      );
    }
    if (planet.id === "jupiter") {
      return (
        <meshStandardMaterial
          color={planet.color}
          emissive={planet.emissive}
          emissiveIntensity={0.05}
          roughness={0.8}
          metalness={0.0}
        />
      );
    }
    return (
      <meshStandardMaterial
        color={planet.color}
        emissive={planet.emissive}
        emissiveIntensity={isGasGiant ? 0.05 : 0.1}
        roughness={planet.roughness}
        metalness={planet.metalness}
      />
    );
  }, [planet]);

  useFrame((state, delta) => {
    if (!groupRef.current || !meshRef.current) return;
    angleRef.current += delta * planet.orbitSpeed;

    const x = Math.cos(angleRef.current) * planet.orbitRadius;
    const z = Math.sin(angleRef.current) * planet.orbitRadius;
    const y = Math.sin(angleRef.current * 0.5) * 0.3;

    groupRef.current.position.set(x, y, z);
    meshRef.current.rotation.y += delta * planet.rotationSpeed * 2;

    if (isActive && onPositionUpdate) {
      onPositionUpdate(index + 1, groupRef.current.position.clone());
    }
  });

  const tilt = planet.id === "uranus" ? Math.PI / 2 : 0.15;

  return (
    <group ref={groupRef}>
      <group rotation={[tilt, 0, 0]}>
        <Sphere
          ref={meshRef}
          args={[planet.size, 64, 64]}
          castShadow
          receiveShadow
        >
          {material}
        </Sphere>
        {planet.id === "earth" && <CloudLayer size={planet.size} />}
        {planet.id === "saturn" && planet.ringColor && (
          <SaturnRings color={planet.ringColor} size={planet.size} />
        )}
        {planet.id === "uranus" && planet.ringColor && (
          <UranusRings color={planet.ringColor} size={planet.size} />
        )}
      </group>
      <PlanetGlow color={planet.glowColor} size={planet.size} />
    </group>
  );
}
