import { useRef, useEffect } from "react";
import { useThree, useFrame } from "@react-three/fiber";
import * as THREE from "three";
import gsap from "gsap";

const CAMERA_POSITIONS = [
  // Sun
  { x: 0, y: 2, z: 12 },
  // Mercury
  { x: 0, y: 1.5, z: 5 },
  // Venus
  { x: 0, y: 2, z: 6 },
  // Earth
  { x: 0, y: 2, z: 6 },
  // Mars
  { x: 0, y: 1.5, z: 5 },
  // Jupiter
  { x: 0, y: 3, z: 12 },
  // Saturn
  { x: 0, y: 4, z: 14 },
  // Uranus
  { x: 0, y: 2.5, z: 10 },
  // Neptune
  { x: 0, y: 2.5, z: 10 },
];

export default function CameraController({ activeIndex, planetPositions }) {
  const { camera } = useThree();
  const targetRef = useRef(new THREE.Vector3());
  const lookAtRef = useRef(new THREE.Vector3());
  const tweenRef = useRef(null);
  const prevIndex = useRef(-1);

  useEffect(() => {
    if (!planetPositions || planetPositions.length === 0) return;
    if (prevIndex.current === activeIndex) return;
    prevIndex.current = activeIndex;

    const planetPos = planetPositions[activeIndex] || new THREE.Vector3(0, 0, 0);
    const camOffset = CAMERA_POSITIONS[activeIndex] || { x: 0, y: 2, z: 10 };

    const targetCamX = planetPos.x + camOffset.x;
    const targetCamY = planetPos.y + camOffset.y;
    const targetCamZ = planetPos.z + camOffset.z;

    if (tweenRef.current) tweenRef.current.kill();

    const obj = {
      camX: camera.position.x,
      camY: camera.position.y,
      camZ: camera.position.z,
      lookX: lookAtRef.current.x,
      lookY: lookAtRef.current.y,
      lookZ: lookAtRef.current.z,
    };

    tweenRef.current = gsap.to(obj, {
      camX: targetCamX,
      camY: targetCamY,
      camZ: targetCamZ,
      lookX: planetPos.x,
      lookY: planetPos.y,
      lookZ: planetPos.z,
      duration: 1.4,
      ease: "power3.inOut",
      onUpdate: () => {
        targetRef.current.set(obj.camX, obj.camY, obj.camZ);
        lookAtRef.current.set(obj.lookX, obj.lookY, obj.lookZ);
      },
    });
  }, [activeIndex, planetPositions, camera]);

  useFrame(() => {
    camera.position.lerp(targetRef.current, 0.08);
    camera.lookAt(lookAtRef.current);
  });

  return null;
}
