import { useRef, useState, useCallback } from "react";
import { Canvas } from "@react-three/fiber";
import { EffectComposer, Bloom } from "@react-three/postprocessing";
import Stars from "./Stars";
import Sun from "./Sun";
import Planet from "./Planet";
import CameraController from "./CameraController";
import { PLANETS } from "../data/planets";

export default function SolarSystem({ activeIndex }) {
  // positions[0] = sun, positions[1..8] = planets
  const [planetPositions, setPlanetPositions] = useState(() =>
    Array(9).fill(null).map(() => ({ x: 0, y: 0, z: 0 }))
  );

  const handlePositionUpdate = useCallback((index, pos) => {
    setPlanetPositions((prev) => {
      const next = [...prev];
      next[index] = pos;
      return next;
    });
  }, []);

  return (
    <Canvas
      camera={{ position: [0, 2, 12], fov: 60, near: 0.1, far: 1000 }}
      shadows
      gl={{ antialias: true, alpha: false }}
      style={{ background: "#000005" }}
    >
      <ambientLight intensity={0.06} />
      <fog attach="fog" args={["#000005", 80, 220]} />

      <Stars />
      <Sun onPositionUpdate={handlePositionUpdate} />

      {PLANETS.map((planet, i) => (
        <Planet
          key={planet.id}
          planet={planet}
          index={i}
          isActive={activeIndex === i + 1}
          onPositionUpdate={handlePositionUpdate}
        />
      ))}

      <CameraController
        activeIndex={activeIndex}
        planetPositions={planetPositions}
      />

      <EffectComposer>
        <Bloom
          intensity={1.2}
          luminanceThreshold={0.3}
          luminanceSmoothing={0.9}
          mipmapBlur
        />
      </EffectComposer>
    </Canvas>
  );
}
