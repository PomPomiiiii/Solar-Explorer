import { useState, useEffect, useRef, useCallback } from "react";

export function useScrollNavigation(totalItems) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const isScrolling = useRef(false);
  const scrollTimeout = useRef(null);
  const touchStartY = useRef(null);

  const navigateTo = useCallback(
    (index) => {
      const clamped = Math.max(0, Math.min(totalItems - 1, index));
      setActiveIndex(clamped);
      setProgress(clamped / (totalItems - 1));
    },
    [totalItems]
  );

  const handleWheel = useCallback(
    (e) => {
      e.preventDefault();
      if (isScrolling.current) return;
      isScrolling.current = true;

      if (e.deltaY > 0) {
        setActiveIndex((prev) => {
          const next = Math.min(prev + 1, totalItems - 1);
          setProgress(next / (totalItems - 1));
          return next;
        });
      } else {
        setActiveIndex((prev) => {
          const next = Math.max(prev - 1, 0);
          setProgress(next / (totalItems - 1));
          return next;
        });
      }

      clearTimeout(scrollTimeout.current);
      scrollTimeout.current = setTimeout(() => {
        isScrolling.current = false;
      }, 800);
    },
    [totalItems]
  );

  const handleTouchStart = useCallback((e) => {
    touchStartY.current = e.touches[0].clientY;
  }, []);

  const handleTouchEnd = useCallback(
    (e) => {
      if (touchStartY.current === null) return;
      const delta = touchStartY.current - e.changedTouches[0].clientY;
      if (Math.abs(delta) < 30) return;
      if (isScrolling.current) return;
      isScrolling.current = true;

      if (delta > 0) {
        setActiveIndex((prev) => {
          const next = Math.min(prev + 1, totalItems - 1);
          setProgress(next / (totalItems - 1));
          return next;
        });
      } else {
        setActiveIndex((prev) => {
          const next = Math.max(prev - 1, 0);
          setProgress(next / (totalItems - 1));
          return next;
        });
      }

      touchStartY.current = null;
      clearTimeout(scrollTimeout.current);
      scrollTimeout.current = setTimeout(() => {
        isScrolling.current = false;
      }, 800);
    },
    [totalItems]
  );

  useEffect(() => {
    window.addEventListener("wheel", handleWheel, { passive: false });
    window.addEventListener("touchstart", handleTouchStart, { passive: true });
    window.addEventListener("touchend", handleTouchEnd, { passive: true });
    return () => {
      window.removeEventListener("wheel", handleWheel);
      window.removeEventListener("touchstart", handleTouchStart);
      window.removeEventListener("touchend", handleTouchEnd);
      clearTimeout(scrollTimeout.current);
    };
  }, [handleWheel, handleTouchStart, handleTouchEnd]);

  return { activeIndex, progress, navigateTo };
}
